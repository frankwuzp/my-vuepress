---
home: true
heroText: 人生天地间，忽如远行客。
tagline: Hi！欢迎来到米斯特乌的主页~
heroImage: /whale-logo.png
#  heroImageStyle: {
#  maxWidth: '600px',
#  width: '100%',
#  display: block,
#  margin: '9rem auto 2rem',
#  background: '#fff',
#  borderRadius: '1rem',
#}
bgImage: ''
bgImageStyle: {
  height: '450px'
}
isShowTitleInHome: true
actionText: 跳转到博客👉
actionLink: https://blog.wuzhiping.top #/views/other/guide
#features:
#- title: Yesterday
#  details: 开发一款看着开心、写着顺手的 vuepress 博客主题
#- title: Today
#  details: 希望帮助更多的人花更多的时间在内容创作上，而不是博客搭建上
#- title: Tomorrow
#  details: 希望更多的爱好者能够参与进来，帮助这个主题更好的成长
---
